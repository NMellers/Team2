﻿public static var ToggleMenu = false;

function Start () {

}

function Update () 
{
}
function OnMouseDown()
{	
		ToggleMenu = true;
		//Debug.Log(ToggleMenu);
}