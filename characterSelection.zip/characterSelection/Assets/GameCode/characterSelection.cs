﻿using UnityEngine;
using System.Collections;

public class characterSelection : MonoBehaviour {


	
	// Update is called once per frame
	void Update () {
	
	}
	void OnGUI()
	{
		GUI.Label( new Rect( 180, 0, 120, 50 ), "Character Selection" );
	}
}
