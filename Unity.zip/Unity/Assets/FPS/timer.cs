﻿using UnityEngine;
using System.Collections;

public class timer : MonoBehaviour
{
	public GUIText time;
	public int remainingTime = 30;
	public int counter = 60;
	
	// Use this for initialization
	void Start ()
	{
		
	}
	
	// Update is called once per frame
	void Update ()
	{
		if (remainingTime == 0) 
		{
			Application.LoadLevel("1");
		}
		else
		{
			UpdateTimer ();
		}
	}
	
	void UpdateTimer()
	{
		if (counter == 0) 
		{ 
			remainingTime --; counter = 60;
		}
		
		counter --;
		
		time.text = "Remaining Time: " + remainingTime + "s";
	}
}

