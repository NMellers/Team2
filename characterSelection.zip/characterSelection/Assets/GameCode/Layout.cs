﻿using UnityEngine;
using System.Collections;

public class Layout : MonoBehaviour {
 
	bool gender =true;
	public int character =0;
	// Update is called once per frame
	void Update () {
	
	}
}
