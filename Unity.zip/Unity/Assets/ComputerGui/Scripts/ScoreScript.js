﻿#pragma strict
//private var score:int = 0;

function Start () {

}

function Update () {

}

 function OnGUI()

 {

   //GUI.Label(Rect(100,100, 100, 50), score);

 }