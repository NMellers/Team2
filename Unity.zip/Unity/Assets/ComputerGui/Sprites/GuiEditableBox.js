﻿/*
public static var reviewOne : String = "";

function Start () 
{

}

function OnGUI()
		{
			if(ReviewButtonScript.review == true)
				{
					reviewOne = GUI.TextArea(Rect(transform.position.x,transform.position.y,200,150), reviewOne, 140);
				}
		}

function Update () 
{
	OnGUI();
	
}

*/

	
	
