﻿using UnityEngine;
using System.Collections;

public class TimerScript : MonoBehaviour
{
	
	public float timer = 0.0f;
	public bool timerStarted = true;
	void Update()
	{
		timerStarted = true;
			if( timerStarted == false )
				timerStarted = true;

		
		if( timerStarted )
			timer += Time.deltaTime;

	}
	
	void OnGUI()
	{
		GUI.Label( new Rect( 180, 0, 120, 50 ), "Timer: " + timer );
	}
	
}