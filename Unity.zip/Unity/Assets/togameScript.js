﻿#pragma strict

private var money : int;

function Start () {
	
}

function Update () 
{
	
}

function OnMouseDown()
{
	Application.LoadLevel("shooter");
}