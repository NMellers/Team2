﻿using UnityEngine;
using System.Collections;

public class Options : MonoBehaviour {

	// Use this for initialization
	void Start () {
		Screen.SetResolution(1280, 640, false);
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
