﻿using UnityEngine;
using System.Collections;

public class EnemyBullet : MonoBehaviour {

	// Use this for initialization
	public float destroyBullet=2;
	
	// Update is called once per frame
	void Update () {
		Destroy (gameObject, destroyBullet);
	}
	void OnTriggerEnter(Collider other)
	{
		Debug.Log ("YOU GOT HIT");
		if (other.gameObject.tag == "player")
			Destroy (other.gameObject);
		Destroy (gameObject);
	}

}